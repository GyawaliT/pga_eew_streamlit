```markdown
# EEW PGA Predictor

This repository organizes the EEW notebook into a small, professional Python package and a Streamlit app.

Features
- Train an XGBoost model to predict Peak Ground Acceleration (PGA) from P-wave features.
- Fetch seismograms from IRIS and extract P-wave windows and features.
- Load trained artifacts and run interactive Streamlit dashboard to predict PGA live.
- Small test to validate feature extraction.

Layout
- data/                        # optional training CSV(s)
- artifacts/                   # produced at runtime (models, preproc objects, plots)
- scripts/
  - run_train.py               # convenience script to train and save artifacts
  - run_app.sh                 # start streamlit app (POSIX)
- src/eew_pga/                 # package code
  - __init__.py
  - config.py
  - utils.py
  - data_io.py
  - preprocessing.py
  - features.py
  - train.py
  - predictor.py
  - iris_client.py
  - viz.py
- app/
  - app.py                     # Streamlit app
- tests/
  - test_features.py
- requirements.txt
- Dockerfile
- .gitignore

Quickstart (local)
1. Create env and install:
   python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt

2. Place your CSV in `data/EEW_features_YYYY-MM-DD.csv` or pass path to training script.

3. Train:
   python scripts/run_train.py --data-path data/EEW_features_YYYY-MM-DD.csv --out-dir artifacts

4. Run app (after artifacts exist):
   bash scripts/run_app.sh

Notes
- Artifacts are saved under `artifacts/` by default:
  - artifacts/xgb_eew_final.joblib
  - artifacts/preproc_objects.joblib
- This repo avoids embedding any tokens/credentials.
- For production use, consider adding Docker/Kubernetes deployment and secrets management.

If you want, I can add:
- Docker Compose and more robust CI (GitHub Actions)
- Unit tests and coverage CI
- Example dataset download automation
```